﻿

$('.divcustomizavel').draggable(
    {
        containment: '#bord',       
    }
);


$('.resizeButton').draggable(
    {
        containment: '#bord',
        drag: function () {

            $('.divcustomizavel').height($('.resizeButton').position().top - 8);
            $('.divcustomizavel').width($('.resizeButton').position().left - 8);
        }
    }
);


$(function () {

    $('.divcustomizavel').css("width", "100px");
});

